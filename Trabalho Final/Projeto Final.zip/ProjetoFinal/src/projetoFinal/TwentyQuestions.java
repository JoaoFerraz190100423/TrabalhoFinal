package projetoFinal;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;


public class TwentyQuestions {

  private Tree tree;
  private TreeNode currentNode;
  private JButton yesButton, noButton, restartButton;
  private JTextPane textPane; 
  private boolean started = false;
  
  private ActionListener btnsListener = new ActionListener() {

    @Override
    public void actionPerformed(ActionEvent e) {
      Object source = e.getSource();

      if (source == yesButton)
        yes();
      else if (source == noButton)
        no();
      else if (source == restartButton)
        restart();

    }
  };

  public static void main(String[] args) {
    TwentyQuestions twentyQuestions = new TwentyQuestions();
    twentyQuestions.tree = new Tree();
    twentyQuestions.tree.loadTree("D:\\Eclipse\\ProjetoFinal\\ProjetoFinal\\src\\projetoFinal\\animal_questions.txt");

    SwingUtilities.invokeLater(new Runnable() {
      @Override
      public void run() {
        twentyQuestions.buildUI();
      }
    });
  }

  private void buildUI() {
    
    JFrame frame = new JFrame("Twenty Questions on Jo�o Ferraz");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    Container contentPane = frame.getContentPane();

    
    JPanel buttonsPanel = new JPanel();

    yesButton = new JButton("Yes");
    yesButton.addActionListener(btnsListener);
    buttonsPanel.add(yesButton, BorderLayout.LINE_START);

    restartButton = new JButton("Start");
    restartButton.addActionListener(btnsListener);
    buttonsPanel.add(restartButton, BorderLayout.LINE_START);

    noButton = new JButton("No");
    noButton.addActionListener(btnsListener);
    buttonsPanel.add(noButton, BorderLayout.LINE_END);

    contentPane.add(buttonsPanel, BorderLayout.PAGE_END);

    
    textPane = new JTextPane();
    textPane.setEditable(false);
    updateText("Think to an animal, then click on Start");

    
    SimpleAttributeSet bSet = new SimpleAttributeSet();
    StyleConstants.setAlignment(bSet, StyleConstants.ALIGN_CENTER);
    StyleConstants.setFontSize(bSet, 22);
    StyledDocument doc = textPane.getStyledDocument();
    doc.setParagraphAttributes(0,  doc.getLength(), bSet, false);

    contentPane.add(textPane, BorderLayout.CENTER);

    frame.setMinimumSize(new Dimension(500, 250));

    
    Dimension objDimension = Toolkit.getDefaultToolkit().getScreenSize();
    int coordX = (objDimension.width - frame.getWidth()) / 2;
    int coordY = (objDimension.height - frame.getHeight()) / 2;
    frame.setLocation(coordX, coordY);

    
    frame.pack();
    frame.setVisible(true);
  }

  
  private void yes() {
    
    if (started && currentNode != null) {
      currentNode = currentNode.yes;

      if (currentNode != null) {
        if (currentNode.isQuestion()) {
          updateText(currentNode.data);
        } else {
          updateText("Would you think to " + currentNode.data + "?");
        }
      } else {
          updateText("I found :)");
      }
    }
  }

  private void no() {
    
    if (started && currentNode != null) {
      currentNode = currentNode.no;

      if (currentNode != null) {
        if (currentNode.isQuestion()) {
          updateText(currentNode.data);
        } else {
          updateText("Would you think to " + currentNode.data + "?");
        }
      } else {
        updateText("I lose :(");
     }
    }
  }

  private void restart() {
    if (started) {
      started = false;
      updateText("Think to an animal, then click on Start");
    } else {
      started = true;
      updateText("Think to an animal, then click on Start");
      currentNode = tree.root;
      updateText(currentNode.data);
    }
  }

  private void updateText(String txt) {
    textPane.setText("\n" + txt);
  }

}
